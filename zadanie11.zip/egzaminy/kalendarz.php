<?php
    $db = mysqli_connect('localhost', 'root', '', 'terminarz');

    $q = "SELECT DISTINCT wpis FROM zadania WHERE dataZadania BETWEEN '2020-07-01' AND '2020-07-07' AND wpis <> '';";
    $r = mysqli_query($db, $q);

        $next_tasks = "";
        while($row = mysqli_fetch_array($r)) {
            $next_tasks .= $row['wpis'] . "; ";
        }

        $q = "SELECT dataZadania, wpis
        FROM zadania
        WHERE miesiac = 'lipiec';";
        $r = mysqli_query($db, $q);
        $kalendarz = mysqli_fetch_all($r, MYSQLI_BOTH);
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Zadania na lipec</title>
   <link rel="stylesheet" href="styl6.css">
</head>
<body>
    <div id="baner">
        <div class="baner1">
            <img src="logo1.png" alt="lipec">
        </div>
        <div class="baner2">
            <h1>TERMINARZ</h1>
            <p>najbliższe zadania:<?= $next_tasks ?></p>
        </div>
    </div>
    <div id="main">      
        <section class="kalendarz">
            <h6><?= $kalendarz['dataZadania'] ?></h6>
            <p><?= $kalendarz['wpis'] ?></p>
        </section>
       
            
        </div>
    <footer>
        <div id="stopka">
        <a href="sierpien.html">Terminarz na sierpień</a>
        <p>Strone wykonał: 0000000000000000000000</p>
        </div>
    </footer>
 
</body>
</html>