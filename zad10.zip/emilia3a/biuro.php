<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Poznaj Europę</title>
    <link rel="stylesheet" href="styl9.css">
</head>
<body>
    <header>
            <h1>BIURO PODRÓRZY</h1>
    </header>
    <aside>
        <h2> Promocje </h2>
        <table>
            <tr>
                <td> Warszawa </td>
                <td> od 600 zł </td>
            </tr>
            <tr>
                <td> Wenecja </td>
                <td> od 1200 zł </td>
            </tr>
            <tr>
                <td> Paryż </td>
                <td> od 100 zł </td>
            </tr>
        </table>
    </aside>
    <main>
            <h2>W tym roku jedziemy do </h2>
            
            <?php
            $conn = mysqli_connect("localhost","root","","podroze");

            

            $kw1 = 'SELECT nazwaPliku, podpis FROM `zdjecia` ORDER BY podpis ;';
            $r1 = mysqli_query($conn, $kw1);



            while($row = mysqli_fetch_array($r1))
            {
                    echo "<img src='". $row["nazwaPliku"]. "' alt='" . $row ["podpis"] ."' >";
            }
            ?>
            
    </main>
    <aside>
            <h2> Kontakt</h2>
            <a href="mailto: biuro@wycieczki.pl"> napisz do nas </a>
            <p>telefon: 444555666</p>
    </aside>
    <section>
            <h3>w poprzednich latach bylismy...</h3>
            <ol>
            <?php

            $kw2 = 'SELECT cel, dataWyjazdu FROM `wycieczki` WHERE dostepna = 0 ;';
            $r2 = mysqli_query($conn, $kw2);

            while($row = mysqli_fetch_array($r2))
            {
                    echo '<li>'.$row["dataWyjazdu"].' pojechaliśmy do '.$row["cel"].'</li>';
            }
            ?>
            </ol>
    </section>


    <footer>
            strone wykonała: 000000000000
    </footer>
    
</body>
</html>