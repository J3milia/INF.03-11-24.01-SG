<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Zadania na lipec</title>
   <link rel="stylesheet" href="styl6.css">
</head>
<body>
    <header>
        <div class="baner1">
            <img src="logo1.png" alt="lipec">
        </div>
        <div class="baner2">
            <h1>TERMINARZ</h1>
            <p>najbliższe zadania:  <?php

            $conn = mysqli_connect("localhost","root","","terminarz");

            $kw1 = 'SELECT DISTINCT wpis FROM zadania WHERE dataZadania BETWEEN "2020-07-01" AND "2020-07-07" AND wpis <> "";';
            $r1 = mysqli_query($conn, $kw1);

            $zadania = "";
            while($row = mysqli_fetch_array($r1)){
                $zadania .= $row["wpis"] . "; ";
            }
                echo $zadania;
            ?></p>
        </div>
    </header>
    <div id="main">     
        <?php

                $kw2 = 'SELECT dataZadania, wpis FROM `zadania` WHERE miesiac = "lipiec";';
                $r2 = mysqli_query($conn, $kw2);

                while($row = mysqli_fetch_array($r2)){
                   echo "<div class='kalendarz'>
                    <h6>".$row["dataZadania"]."</h6>
                    <p>".$row["wpis"]."</p>
                    </div>";
                }
                mysqli_close($conn);

        ?>
    </div>
    <footer>
        <div id="stopka">
        <a href="sierpien.html">Terminarz na sierpień</a>
        <p>Strone wykonał: 0000000000000000000000</p>
        </div>
    </footer>
 
</body>
</html>